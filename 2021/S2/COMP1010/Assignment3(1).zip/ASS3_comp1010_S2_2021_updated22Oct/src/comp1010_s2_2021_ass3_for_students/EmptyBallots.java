//ID, NAME (For example, "40404040, Janet Kim")
//Put x inside [] below:
//[] 	This assignment is entirely my own work and 
// 		I have not seen anyone else's code or design
package comp1010_s2_2021_ass3_for_students;
public class EmptyBallots {

	public Ballot head;
	
	
	/** 5 marks - Pass level
	 * 
	 * Create a list with n empty ballots, with id from 0 to n-1
	 * 
	 * @param n - the number of empty ballots to create in the list
	 */
	public EmptyBallots(int n) {
		//
		// TODO - 5 marks
		
		
	}
	
	/** 5 marks - Pass level
	 * 
	 * Remove the first empty ballot from the list
	 * 
	 * @return the removed ballot if there are still empty ballots
	 *         left in the list, null otherwise
	 */
	public Ballot remove() {
		//
		// TODO - 5 marks
		return null;
		
	}
	
	/** 5 marks - Pass level
	 * 
	 * Check if the ids of the empty ballots in the list are sequential
	 * in an increasing incremental order. For example, if the first empty ballot
	 * id is 13, then it should be followed by ballots with ids 14, 15,
	 * and so on.
	 * 
	 * @return true if the ids in the empty ballots are sequential in 
	 *         increasing incremental order, or if the list is empty, false otherwise
	 */
	public boolean isValid() {
		//
		// TODO - 5 marks
		
		return false;
	}
	
}
